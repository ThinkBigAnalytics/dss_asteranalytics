DROP TABLE IF EXISTS advaa_wrkspc1.dss_dss_700_tfidf_input1; 
CREATE fact TABLE advaa_wrkspc1.dss_dss_700_tfidf_input1 DISTRIBUTE BY hash(term) AS
SELECT docid, ngram AS term, frequency AS count
FROM advaa_wrkspc1.dss_tfidf_token1;