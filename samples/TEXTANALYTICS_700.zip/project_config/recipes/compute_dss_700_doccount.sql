DROP TABLE IF EXISTS advaa_wrkspc1.dss_dss_700_doccount; 
CREATE TABLE advaa_wrkspc1.dss_dss_700_doccount DISTRIBUTE BY REPLICATION AS
SELECT COUNT(DISTINCT docid) 
FROM advaa_wrkspc1.dss_dss_700_tfidf_input1;