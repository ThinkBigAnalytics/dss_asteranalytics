DROP TABLE IF EXISTS dss.dss_doccount_out; 
CREATE TABLE dss.dss_doccount_out DISTRIBUTE BY REPLICATION AS
SELECT COUNT(DISTINCT docid) as doccount
FROM dss.dss_620_tfidf_input1;