DROP TABLE IF EXISTS dss.dss_620_tfidf_input1; 
CREATE fact TABLE dss.dss_620_tfidf_input1 DISTRIBUTE BY hash(term) AS
SELECT docid, ngram AS term, frequency AS count
FROM dss.tfidf_token_1;