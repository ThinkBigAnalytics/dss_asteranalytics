'''
Created on May 15, 2017

@author: dt186022
'''
textTokenizerOuputConnectionConfig = {'table': 'text_tokenized'}
textTokenizerInputConnectionConfig = {'table': 'text_chunked', 'schema': 'bs186029'}