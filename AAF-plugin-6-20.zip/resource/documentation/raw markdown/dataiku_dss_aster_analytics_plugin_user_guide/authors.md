# Authors

&nbsp;


**DONNA APRIL TEODORO**  
Data Science Practice  
Global Delivery Center – Manila  
[donnaapril.teodoro@teradata.com](mailto:donnaapril.teodoro@teradata.com)

&nbsp;

**JOSEPH ALVIN DE JESUS**  
Data Science Practice  
Global Delivery Center – Manila  
[josephalvin.dejesus@teradata.com](mailto:josephalvin.dejesus@teradata.com)

&nbsp;



**KEVIN CONTRERAS**  
Data Science Practice  
Global Delivery Center – Manila  
[kevin.contreras@teradata.com](mailto:kevin.contreras@teradata.com)

