# V. Aster Analytics Plugin Installation 

---

1.	In DSS Settings page (accessible through Admin Tools button), select Plugins tab, then select ADVANCED option.

    ![](/assets/install_1.png)
    &nbsp;

2.	Click on Choose File and browse to the location of the Aster Analytics zip file in your local filesystem.

    &nbsp;

3.    If a previous installation of Aster Analytics plugin exists, check Is update.

    &nbsp;
    
4.    Click on UPLOAD button.

    &nbsp;

5.    When upload succeeds, click on Reload button, or do a hard refresh (Ctrl + F5) on all open Dataiku browsers for the change to take effect.
