from astermain import *

# prepare datasets and queries; execute
asterDo()