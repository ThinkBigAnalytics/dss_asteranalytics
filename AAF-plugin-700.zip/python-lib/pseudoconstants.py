'''
Created on Jun 7, 2017

@author: DT186022
'''


PARTITION_KEY_MAPPING = {'PartitionByAny': 'PARTITION BY ANY',
                         'PartitionByKey': 'PARTITION BY ',
                         'PartitionByOne': 'PARTITION BY 1',
                         'Dimension': 'DIMENSION'}